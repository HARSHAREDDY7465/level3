document.getElementById('applyBtn').addEventListener('click', function () {
    window.location.href = '/License-Selection';
  });


function openApplication(applicationid,flowid){
        window.location.href = `/Question?applicationid=${applicationid}&flowid=${flowid}`;
    }

async function discardApplication(applicationid){
if (!confirm("Discard this application? This will delete it permanently."))
      return;
    try{
    const token = await getRequestVerificationToken();
      // 2) delete the application
      await fetch(`/_api/lpi_applications(${applicationid})`, {
        method: "DELETE",
        headers: {
          __RequestVerificationToken: token,
          "If-Match": "*",
        },
      });
      window.location.href = "/Application";
    }catch (e) {
      console.error(e);
      alert("Failed to discard/delete the application. Please try again.");
    }
}

  // Retrieve Portal token
function getRequestVerificationToken() {
    return new Promise((resolve, reject) => {
      shell.getTokenDeferred().done(resolve).fail(reject);
    });
  }
