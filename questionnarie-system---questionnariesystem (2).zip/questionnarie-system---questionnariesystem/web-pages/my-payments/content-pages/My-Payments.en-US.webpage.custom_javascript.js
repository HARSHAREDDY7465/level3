$(document).ready(function () {
  const listSelector = ".entitylist.entity-grid";
  function injectButtons($list) {
    var $grid = $list.find(".view-grid table");
    if (!$grid.length) return;
    var $headerRow = $grid.find("thead tr");
    if (!$headerRow.find(".custom-action-col").length) {
      $headerRow.append(
        '<th class="custom-action-col">Actions</th>'
      );
    }
    $grid.find("tbody tr").each(function () {
      var $row = $(this);
      if ($row.find(".custom-action-col").length) return;
      var rowId = $row.attr("data-id");
      if (!rowId) return;
      const $cells = $row.children("td");
      const rawValue = $cells.filter('[data-attribute="lpi_paymentstatus"]').attr("data-value");
      const paymentStatus = rawValue ? JSON.parse(rawValue).Value : null;
       var html =
        '<td class="custom-action-col">' +
        '<div class="license-action-wrap">';
        //View Button
        html += '<button type="button" class="btn view-receipt-btn" data-row-id="' + rowId + '"><i class="fa fa-eye" style="margin-right:5px"></i>View</button>'
       
      if(paymentStatus===855890002){
       html+=
        '<button type="button" class="btn pay-now-btn" data-row-id="' + rowId + '"><i class="fa fa-credit-card" style="margin-right:5px"></i>Pay Now</button>';
      } 
       html+='</div>'+
        '</td>';
      $row.append(html);
    });
  }
  $(listSelector).on("loaded", function () {
    injectButtons($(this));
  });

  //The handler of view button
  $(document).on("click",".view-receipt-btn", function(){
    const rowId = $(this).data("row-id");

    window.location.href = "/Payment-Receipt-Details?id=" + rowId;
  });
});