$(document).ready(function (){
    $("#printLicenseBtn").on("click", function (e) {
        e.preventDefault();
        window.print();
    });

    $("#backToLicensesBtn").on("click", function (e){
        e.preventDefault();
        window.location.href = "/License-Details";
    });
})