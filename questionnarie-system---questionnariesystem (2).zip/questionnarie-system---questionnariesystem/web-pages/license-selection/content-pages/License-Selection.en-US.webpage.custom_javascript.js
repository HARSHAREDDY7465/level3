document.addEventListener("DOMContentLoaded", async () => {
  document.getElementById("nextBtn").addEventListener("click", goNext);
});
//  NEXT BUTTON LOGIC
function goNext() {
  const boardValue = document.getElementById("boardDropdown").value;
  const boardLabel = boardDropdown.selectedOptions[0].text;
  const license = document.getElementById("licenseDropdown").value;
 
  if (!boardValue || !license) {
    alert("Please select both Board and License");
    return;
  }
 
  // Redirect to next page with params
  window.location.href = `/Question?boardValue=${boardValue}&boardLabel=${boardLabel}&license=${license}`;
}