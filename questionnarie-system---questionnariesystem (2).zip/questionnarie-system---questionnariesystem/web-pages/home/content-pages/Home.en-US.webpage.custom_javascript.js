 function openApplication(applicationid,flowid){
        window.location.href = `/Question?applicationid=${applicationid}&flowid=${flowid}`;
    }